package com.estudo.estudo;

public class Calendario {
    private Long jogoId;
    private String data;

    // Getters e Setters
    public Long getJogoId() {
        return jogoId;
    }

    public void setJogoId(Long jogoId) {
        this.jogoId = jogoId;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }
}

