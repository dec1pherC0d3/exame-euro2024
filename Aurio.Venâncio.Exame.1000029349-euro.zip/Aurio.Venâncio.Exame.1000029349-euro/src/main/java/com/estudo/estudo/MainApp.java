package com.estudo.estudo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.Scanner;
import java.util.Random;

public class MainApp {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        EuroDAO euroDAO = context.getBean(EuroDAO.class);
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            // Clear screen and show menu
            System.out.print("\033[H\033[2J");
            System.out.flush();

            System.out.println("\033[1;34mMenu de Consultas:\033[0m");
            System.out.println("\033[1;32m1. Ver informações de um país organizador\033[0m");
            System.out.println("\033[1;32m2. Ver informações de estádios\033[0m");
            System.out.println("\033[1;32m3. Ver informações de cidades\033[0m");
            System.out.println("\033[1;32m4. Ver calendário e fases de qualificação\033[0m");
            System.out.println("\033[1;32m5. Ver informações de equipas\033[0m");
            System.out.println("\033[1;32m6. Ver informações de jogadores\033[0m");
            System.out.println("\033[1;32m7. Ver estatísticas de jogos\033[0m");
            System.out.println("\033[1;32m8. Ver informações detalhadas de um jogo\033[0m");
            System.out.println("\033[1;32m9. Ver ranking de melhores jogadores do grupo\033[0m");
            System.out.println("\033[1;32m10. Jogar (Simular resultados de jogos)\033[0m");
            System.out.println("\033[1;32m11. Marcar Gols (Simular gols de jogadores)\033[0m");
            System.out.println("\033[1;31m12. Sair\033[0m");
            System.out.print("\033[1;33mEscolha uma opção: \033[0m");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("\033[1;33mDigite o nome do país: \033[0m");
                    String pais = scanner.nextLine();
                    euroDAO.consultarPais(pais);
                    break;
                case 2:
                    euroDAO.consultarEstadios();
                    break;
                case 3:
                    euroDAO.consultarCidades();
                    break;
                case 4:
                    euroDAO.consultarCalendarioFases();
                    break;
                case 5:
                    System.out.print("\033[1;33mDigite o nome da equipa: \033[0m");
                    String equipa = scanner.nextLine();
                    euroDAO.consultarEquipa(equipa);
                    break;
                case 6:
                    System.out.print("\033[1;33mDigite o nome do jogador: \033[0m");
                    String jogador = scanner.nextLine();
                    euroDAO.consultarJogador(jogador);
                    break;
                case 7:
                    euroDAO.consultarEstatisticasJogos();
                    break;
                case 8:
                    System.out.print("\033[1;33mDigite o ID do jogo: \033[0m");
                    int jogoId = scanner.nextInt();
                    euroDAO.consultarDetalhesJogo(jogoId);
                    break;
                case 9:
                    euroDAO.consultarRankingGrupo();
                    break;
                    case 10:
                    euroDAO.simularResultadosJogos();
                    break;
                case 11:
                    euroDAO.marcarGolsAleatorios();
                    break;
                case 12:
                    System.out.println("\033[1;31mSaindo...\033[0m");
                    break;
                default:
                    System.out.println("\033[1;31mOpção inválida!\033[0m");
            }

            if (choice != 12) {
                System.out.println("\nPressione Enter para continuar...");
                scanner.nextLine(); // Wait for user to press Enter
            }

        } while (choice != 12);

        scanner.close();
        context.close();
    }
}