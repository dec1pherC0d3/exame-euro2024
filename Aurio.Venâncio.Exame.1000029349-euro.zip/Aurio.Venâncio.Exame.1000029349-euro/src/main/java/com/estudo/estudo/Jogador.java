package com.estudo.estudo;

public class Jogador {
    private Long id;
    private String nome;
    private Long equipaId;

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getEquipaId() {
        return equipaId;
    }

    public void setEquipaId(Long equipaId) {
        this.equipaId = equipaId;
    }

    public String getTotalGols() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getTotalGols'");
    }
}

