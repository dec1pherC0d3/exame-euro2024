package com.estudo.estudo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Random;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EuroDAOImpl implements EuroDAO {
    private final DataSource dataSource;

    @Autowired
    private JdbcTemplate jdbcTemplate;

    public EuroDAOImpl(DataSource dataSource) {
        this.dataSource = dataSource;
    }
    
    @Override
    public void consultarPais(String nome) {
        try {
            String sql = "SELECT * FROM pais WHERE nome = ?";
            Pais pais = jdbcTemplate.queryForObject(sql, new Object[]{nome}, new BeanPropertyRowMapper<>(Pais.class));
            if (pais != null) {
                System.out.println("País: " + pais.getNome());
            } else {
                System.out.println("País não encontrado.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar país: " + e.getMessage());
        }
    }

    @Override
    public void consultarEstadios() {
        try {
            String sql = "SELECT * FROM estadio";
            List<Estadio> estadios = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Estadio.class));
            for (Estadio estadio : estadios) {
                System.out.println("Estádio: " + estadio.getNome() + ", Cidade: " + estadio.getCidadeId());
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar estádios: " + e.getMessage());
        }
    }

    @Override
    public void consultarCidades() {
        try {
            String sql = "SELECT * FROM cidade";
            List<Cidade> cidades = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Cidade.class));
            for (Cidade cidade : cidades) {
                System.out.println("Cidade: " + cidade.getNome() + ", País: " + cidade.getPaisId());
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar cidades: " + e.getMessage());
        }
    }

    @Override
    public void consultarCalendarioFases() {
        try {
            String sql = "SELECT * FROM calendario";
            List<Calendario> calendarios = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(Calendario.class));
            for (Calendario calendario : calendarios) {
                System.out.println("Jogo ID: " + calendario.getJogoId() + ", Data: " + calendario.getData());
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar calendário de fases: " + e.getMessage());
        }
    }

    @Override
    public void consultarEquipa(String nome) {
        try {
            String sql = "SELECT * FROM equipa WHERE nome = ?";
            Equipa equipa = jdbcTemplate.queryForObject(sql, new Object[]{nome}, new BeanPropertyRowMapper<>(Equipa.class));
            if (equipa != null) {
                System.out.println("Equipa: " + equipa.getNome() + ", País: " + equipa.getPaisId());
            } else {
                System.out.println("Equipa não encontrada.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar equipa: " + e.getMessage());
        }
    }

    @Override
    public void consultarJogador(String nome) {
        try {
            String sql = "SELECT * FROM jogador WHERE nome = ?";
            Jogador jogador = jdbcTemplate.queryForObject(sql, new Object[]{nome}, new BeanPropertyRowMapper<>(Jogador.class));
            if (jogador != null) {
                System.out.println("Jogador: " + jogador.getNome() + ", Equipa: " + jogador.getEquipaId());
            } else {
                System.out.println("Jogador não encontrado.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar jogador: " + e.getMessage());
        }
    }

    @Override
    public void consultarEstatisticasJogos() {
        try {
            String sql = "SELECT * FROM estatistica_jogo";
            List<EstatisticaJogo> estatisticas = jdbcTemplate.query(sql, new BeanPropertyRowMapper<>(EstatisticaJogo.class));
            for (EstatisticaJogo estatistica : estatisticas) {
                System.out.println("Jogo ID: " + estatistica.getJogoId() + ", Equipa ID: " + estatistica.getEquipaId() + ", Remates: " + estatistica.getRemates());
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar estatísticas de jogos: " + e.getMessage());
        }
    }

    @Override
    public void consultarDetalhesJogo(int jogoId) {
        try {
            // Consulta os detalhes do jogo
            String sqlJogo = "SELECT * FROM jogo WHERE id = ?";
            Jogo jogo = jdbcTemplate.queryForObject(sqlJogo, new Object[]{jogoId}, new BeanPropertyRowMapper<>(Jogo.class));
        
            if (jogo != null) {
                System.out.println("Detalhes do Jogo:");
                System.out.println("ID do Jogo: " + jogo.getId());
                System.out.println("ID do Mandante: " + jogo.getMandanteId());
                System.out.println("ID do Visitante: " + jogo.getVisitanteId());
                System.out.println("Placar Mandante: " + jogo.getPlacarMandante());
                System.out.println("Placar Visitante: " + jogo.getPlacarVisitante());
                System.out.println("Data: " + jogo.getData());
                System.out.println("ID do Estádio: " + jogo.getEstadioId());
                System.out.println("Fase: " + jogo.getFase());
        
                // Consulta as substituições do jogo
                String sqlSubstituicoes = "SELECT * FROM substituicao WHERE jogo_id = ?";
                List<Substituicao> substituicoes = jdbcTemplate.query(sqlSubstituicoes, new Object[]{jogoId}, new BeanPropertyRowMapper<>(Substituicao.class));
                System.out.println("Substituições:");
                for (Substituicao substituicao : substituicoes) {
                    System.out.println("Jogador Entrou ID: " + substituicao.getJogadorEntradaId() + ", Jogador Saiu ID: " + substituicao.getJogadorSaidaId() + ", Minuto: " + substituicao.getMinuto());
                }
        
                // Consulta os golos do jogo
                String sqlGolos = "SELECT * FROM golo WHERE jogo_id = ?";
                List<Golo> golos = jdbcTemplate.query(sqlGolos, new Object[]{jogoId}, new BeanPropertyRowMapper<>(Golo.class));
                System.out.println("Golos:");
                for (Golo golo : golos) {
                    System.out.println("Jogador ID: " + golo.getJogadorId() + ", Minuto: " + golo.getMinuto() + ", Tipo: " + golo.getTipo());
                }
        
                // Consulta os cartões do jogo
                String sqlCartoes = "SELECT * FROM cartao WHERE jogo_id = ?";
                List<Cartao> cartoes = jdbcTemplate.query(sqlCartoes, new Object[]{jogoId}, new BeanPropertyRowMapper<>(Cartao.class));
                System.out.println("Cartões:");
                for (Cartao cartao : cartoes) {
                    System.out.println("Jogador ID: " + cartao.getJogadorId() + ", Tipo: " + (cartao.getTipo() == 1 ? "Amarelo" : "Vermelho") + ", Data: " + cartao.getData());
                }
            } else {
                System.out.println("Jogo não encontrado.");
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar detalhes do jogo: " + e.getMessage());
        }
    }

    @Override
    public void simularResultadosJogos() {
        try {
            Random random = new Random();
            String sqlJogos = "SELECT id FROM jogo";
            List<Integer> jogos = jdbcTemplate.queryForList(sqlJogos, Integer.class);
        
            for (Integer jogoId : jogos) {
                int placarMandante = random.nextInt(5); // Gera um placar entre 0 e 4
                int placarVisitante = random.nextInt(5); // Gera um placar entre 0 e 4
        
                String sqlUpdate = "UPDATE jogo SET placar_mandante = ?, placar_visitante = ? WHERE id = ?";
                jdbcTemplate.update(sqlUpdate, placarMandante, placarVisitante, jogoId);
        
                System.out.println("Jogo ID: " + jogoId + " - Placar atualizado: Mandante " + placarMandante + " x " + placarVisitante + " Visitante");
            }
        } catch (Exception e) {
            System.out.println("Erro ao simular resultados de jogos: " + e.getMessage());
        }
    }

    @Override
    public void marcarGolsAleatorios() {
        try {
            Random random = new Random();
            String sqlJogadores = "SELECT id FROM jogador";
            List<Integer> jogadores = jdbcTemplate.queryForList(sqlJogadores, Integer.class);
        
            for (Integer jogadorId : jogadores) {
                int golsMarcados = random.nextInt(5); // Gera um número aleatório de gols entre 0 e 4
        
                String sqlUpdate = "INSERT INTO melhor_marcador (jogador_id, total_golos) VALUES (?, ?) " +
                                   "ON CONFLICT (jogador_id) DO UPDATE SET total_golos = melhor_marcador.total_golos + ?";
                jdbcTemplate.update(sqlUpdate, jogadorId, golsMarcados, golsMarcados);
        
                System.out.println("Jogador ID: " + jogadorId + " - Gols marcados: " + golsMarcados);
            }
        } catch (Exception e) {
            System.out.println("Erro ao marcar gols aleatórios: " + e.getMessage());
        }
    }
    

    @Override
    public void consultarRankingGrupo() {
        try {
            String sql = "SELECT jogador.nome, melhor_marcador.total_golos " +
                         "FROM jogador " +
                         "JOIN melhor_marcador ON jogador.id = melhor_marcador.jogador_id " +
                         "ORDER BY melhor_marcador.total_golos DESC " +
                         "LIMIT 3";
    
            List<Jogador> jogadores = jdbcTemplate.query(sql, (rs, rowNum) -> {
                Jogador jogador = new Jogador();
                jogador.setNome(rs.getString("nome"));
                jogador.setTotalGols(rs.getInt("total_golos"));
                return jogador;
            });
    
            System.out.println("\033[1;34mRanking dos Melhores Marcadores:\033[0m");
            for (Jogador jogador : jogadores) {
                System.out.println("\033[1;33mJogador:\033[0m " + jogador.getNome() + " \033[1;32mTotal de Gols:\033[0m " + jogador.getTotalGols());
            }
        } catch (Exception e) {
            System.out.println("Erro ao consultar ranking de melhores marcadores: " + e.getMessage());
        }
    }
}    