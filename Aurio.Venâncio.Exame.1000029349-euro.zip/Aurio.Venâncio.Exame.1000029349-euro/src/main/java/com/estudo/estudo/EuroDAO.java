package com.estudo.estudo;

public interface EuroDAO {
    void consultarPais(String nome);
    void consultarEstadios();
    void consultarCidades();
    void consultarCalendarioFases();
    void consultarEquipa(String nome);
    void consultarJogador(String nome);
    void consultarEstatisticasJogos();
    void consultarDetalhesJogo(int jogoId);
    void consultarRankingGrupo();
    void simularResultadosJogos();
    void marcarGolsAleatorios();
}

