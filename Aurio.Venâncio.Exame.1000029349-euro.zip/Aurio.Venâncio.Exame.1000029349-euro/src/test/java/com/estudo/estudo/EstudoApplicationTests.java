package com.estudo.estudo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudoApplicationTests {

	@Test
	void contextLoads() {
	}

}
